package roadgraph;
import java.util.ArrayList;
import java.util.List;

import geography.GeographicPoint;
public class MapNode implements Comparable<MapNode>{
	private GeographicPoint locationOfNode;
	private List<MapEdge> mapEdge;
	private double distanceToStart = Double.NEGATIVE_INFINITY;
	public double getDistanceToStart() {
		return this.distanceToStart;
	}
	public void setDistanceToStart(double distanceee) {
		this.distanceToStart = distanceee;
	}
	public MapNode() {
		mapEdge = new ArrayList<>();
	}
	public MapNode(GeographicPoint loc) {
		this.locationOfNode = loc;
		mapEdge = new ArrayList<>();
	}
	public int getNumberOfEdge() {
		return mapEdge.size();
	}

	public GeographicPoint getLocationOfNode() {
		return locationOfNode;
	}
	public void setLocationOfNode(GeographicPoint locationOfNode) {
		this.locationOfNode = locationOfNode;
	}
	public List<MapEdge> getMapEdge() {
		return mapEdge;
	}
	public void setMapEdge(List<MapEdge> mapEdge) {
		this.mapEdge = mapEdge;
	}
	public void addEdge(MapEdge mapEdge) {
		this.mapEdge.add(mapEdge);
	}
	public double distanceToNode(MapNode other) {
		return this.locationOfNode.distance(other.locationOfNode);
	}
	
	@Override
	// To week 3
	public int compareTo(MapNode o) {
		// TODO Auto-generated method stub
		int result;
		double distanceCurr = this.getDistanceToStart();
		double distanceO = o.getDistanceToStart();
		if(distanceCurr > distanceO) {
			result =1;
		} else if(distanceCurr < distanceO) {
			result = -1;
		} else {
			result = 0;
		}
		return result;
	}
}
